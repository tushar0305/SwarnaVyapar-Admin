'use server';

import { randomUUID } from 'crypto';
import { revalidatePath } from 'next/cache';
import { getServiceRoleClient } from '@/lib/supabase/admin';
import {
  logAdminAction,
  requireAdminPermission,
  requireSuperAdmin,
} from './admin-auth.service';

const BYPASS_ID = '00000000-0000-0000-0000-000000000000';
const MILLICREDITS_PER_CREDIT = 500;
const MAX_GRANT_CREDITS = 20_000;

export type TimelineEvent = {
  at: string;
  kind: string;
  title: string;
  detail: string;
};

export type ShopMember = {
  userId: string;
  role: string;
  active: boolean;
  email: string | null;
  lastSignInAt: string | null;
  createdAt: string;
};

export async function getShopTimeline(shopId: string, limit = 60): Promise<TimelineEvent[]> {
  await requireSuperAdmin();
  const { data, error } = await getServiceRoleClient().rpc('admin_shop_timeline', {
    p_shop_id: shopId,
    p_limit: limit,
  });
  if (error) throw error;
  return (Array.isArray(data) ? data : []).map((row: Record<string, unknown>) => ({
    at: String(row.at ?? ''),
    kind: String(row.kind ?? ''),
    title: String(row.title ?? ''),
    detail: String(row.detail ?? ''),
  }));
}

export async function getShopMembers(shopId: string): Promise<ShopMember[]> {
  await requireSuperAdmin();
  const { data, error } = await getServiceRoleClient().rpc('admin_shop_members', {
    p_shop_id: shopId,
  });
  if (error) throw error;
  return (Array.isArray(data) ? data : []).map((row: Record<string, unknown>) => ({
    userId: String(row.userId ?? ''),
    role: String(row.role ?? ''),
    active: Boolean(row.active),
    email: row.email ? String(row.email) : null,
    lastSignInAt: row.lastSignInAt ? String(row.lastSignInAt) : null,
    createdAt: String(row.createdAt ?? ''),
  }));
}

/**
 * Credits land in the same ledger/lot tables as the shop app's wallet engine.
 * Promo lots are spent first and can expire; paid lots never expire.
 */
export async function grantShopCredits(input: {
  shopId: string;
  credits: number;
  kind: 'promo' | 'paid';
  expiresInDays: number | null;
  reason: string;
  requestId: string;
}): Promise<{ availableMc: number; duplicate: boolean }> {
  const admin = await requireAdminPermission('manage_shops');
  const credits = Math.floor(Number(input.credits));
  if (!Number.isFinite(credits) || credits <= 0 || credits > MAX_GRANT_CREDITS) {
    throw new Error(`Grant between 1 and ${MAX_GRANT_CREDITS.toLocaleString('en-IN')} credits`);
  }
  const reason = input.reason.trim();
  if (!reason) throw new Error('A reason is required');
  const expiresAt =
    input.kind === 'promo' && input.expiresInDays && input.expiresInDays > 0
      ? new Date(Date.now() + input.expiresInDays * 86_400_000).toISOString()
      : null;

  const { data, error } = await getServiceRoleClient().rpc('admin_grant_wallet_credit', {
    p_shop_id: input.shopId,
    p_amount_mc: credits * MILLICREDITS_PER_CREDIT,
    p_idempotency_key: `admin-grant:${input.requestId || randomUUID()}`,
    p_lot_kind: input.kind,
    p_expires_at: expiresAt,
    p_reason: reason,
    p_actor_id: admin.id === BYPASS_ID ? null : admin.user_id,
  });
  if (error) throw new Error(error.message);

  const result = (data ?? {}) as { availableMc?: number; duplicate?: boolean };
  if (!result.duplicate) {
    await logAdminAction(
      'wallet_credit_granted',
      'shop',
      input.shopId,
      { shopId: input.shopId, credits, kind: input.kind, expiresAt },
      reason
    );
  }

  revalidatePath(`/shops/${input.shopId}`);
  revalidatePath('/credits');
  revalidatePath('/overview');
  return { availableMc: Number(result.availableMc ?? 0), duplicate: Boolean(result.duplicate) };
}

export async function setShopWalletFrozen(input: {
  shopId: string;
  frozen: boolean;
  reason: string;
}): Promise<void> {
  await requireAdminPermission('manage_shops');
  const reason = input.reason.trim();
  if (!reason) throw new Error('A reason is required');

  const supabase = getServiceRoleClient();
  await supabase
    .from('shop_wallets')
    .upsert({ shop_id: input.shopId }, { onConflict: 'shop_id', ignoreDuplicates: true });
  const { error } = await supabase
    .from('shop_wallets')
    .update({ frozen: input.frozen, updated_at: new Date().toISOString() })
    .eq('shop_id', input.shopId);
  if (error) throw new Error(error.message);

  await logAdminAction(
    input.frozen ? 'wallet_frozen' : 'wallet_unfrozen',
    'shop',
    input.shopId,
    { shopId: input.shopId, frozen: input.frozen },
    reason
  );
  revalidatePath(`/shops/${input.shopId}`);
  revalidatePath('/credits');
}

export async function getRecentJobRuns(limit = 40) {
  await requireSuperAdmin();
  const { data, error } = await getServiceRoleClient()
    .from('cron_job_runs')
    .select('job_name, run_date, status, affected, error, started_at, finished_at')
    .order('started_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}
