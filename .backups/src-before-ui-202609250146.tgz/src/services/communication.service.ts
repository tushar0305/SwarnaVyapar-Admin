'use server';

import { createServerClient } from '@/lib/supabase/server';
import { getServiceRoleClient } from '@/lib/supabase/admin';
import { requireSuperAdmin, logAdminAction } from './admin-auth.service';

interface EmailMessage {
  to: string[];
  subject: string;
  body: string;
  isHtml?: boolean;
}

interface Notification {
  shopId: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  actionUrl?: string;
  expiresAt?: string;
}

interface SupportTicket {
  shopId: string;
  subject: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  category?: string;
}

/**
 * Send email to specific shops
 */
export async function sendEmailToShops(shopIds: string[], message: EmailMessage) {
  const admin = await requireSuperAdmin();
  const supabase = await createServerClient();
  
  // Get shop emails
  const { data: shops } = await supabase
    .from('shops')
    .select('id, shop_name, email')
    .in('id', shopIds);
  
  if (!shops || shops.length === 0) {
    throw new Error('No shops found');
  }
  
  // TODO: Integrate with actual email service (SendGrid, AWS SES, etc.)
  // For now, log the action
  const emailAddresses = shops.filter(s => s.email).map(s => s.email);
  
  await logAdminAction(
    'email_sent',
    'communication',
    'bulk_email',
    {
      recipients: shopIds,
      subject: message.subject,
      recipientCount: emailAddresses.length,
    },
    `Sent email to ${emailAddresses.length} shops: ${message.subject}`
  );
  
  // Store email record
  await supabase.from('admin_communications').insert({
    admin_id: admin.id,
    type: 'email',
    recipients: shopIds,
    subject: message.subject,
    message: message.body,
    sent_at: new Date().toISOString(),
  });
  
  return {
    success: true,
    sentCount: emailAddresses.length,
    recipients: emailAddresses,
  };
}

/**
 * Send in-app notification to shops
 */
export async function sendNotificationToShops(shopIds: string[], notification: Notification) {
  const admin = await requireSuperAdmin();
  const supabase = await createServerClient();
  
  const notifications = shopIds.map(shopId => ({
    shop_id: shopId,
    title: notification.title,
    message: notification.message,
    type: notification.type,
    action_url: notification.actionUrl,
    expires_at: notification.expiresAt,
    is_read: false,
    created_by: admin.id,
  }));
  
  const { error } = await supabase
    .from('shop_notifications')
    .insert(notifications);
  
  if (error) throw error;
  
  await logAdminAction(
    'notification_sent',
    'communication',
    'bulk_notification',
    {
      recipients: shopIds,
      title: notification.title,
      type: notification.type,
    },
    `Sent ${notification.type} notification to ${shopIds.length} shops`
  );
  
  return {
    success: true,
    sentCount: shopIds.length,
  };
}

/**
 * Broadcast message to all active shops
 */
export async function broadcastMessage(message: {
  title: string;
  body: string;
  type: 'email' | 'notification' | 'both';
  priority: 'normal' | 'high';
}) {
  await requireSuperAdmin();
  const supabase = await createServerClient();
  
  // Get all active shops
  const { data: shops } = await supabase
    .from('shops')
    .select('id, email')
    .eq('is_active', true);
  
  if (!shops || shops.length === 0) {
    throw new Error('No active shops found');
  }
  
  const shopIds = shops.map(s => s.id);
  
  const results: any = {};
  
  if (message.type === 'email' || message.type === 'both') {
    const emailResult = await sendEmailToShops(shopIds, {
      to: shops.filter(s => s.email).map(s => s.email!),
      subject: message.title,
      body: message.body,
      isHtml: true,
    });
    results.email = emailResult;
  }
  
  if (message.type === 'notification' || message.type === 'both') {
    const notifResult = await sendNotificationToShops(shopIds, {
      shopId: '', // Not used in bulk
      title: message.title,
      message: message.body,
      type: message.priority === 'high' ? 'warning' : 'info',
    });
    results.notification = notifResult;
  }
  
  return {
    success: true,
    totalShops: shopIds.length,
    results,
  };
}

/**
 * Create support ticket (admin-initiated on behalf of a shop)
 */
export async function createSupportTicket(ticket: Omit<SupportTicket, 'status'>) {
  const admin = await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  const { data, error } = await supabase
    .from('support_tickets')
    .insert({
      shop_id: ticket.shopId,
      subject: ticket.subject,
      description: ticket.description,
      priority: ticket.priority,
      status: 'open',
      category: ticket.category || null,
      created_by: admin.user_id,
    })
    .select()
    .single();

  if (error) throw error;

  await logAdminAction(
    'support_ticket_created',
    'support',
    data.id,
    {
      shopId: ticket.shopId,
      priority: ticket.priority,
      subject: ticket.subject,
    },
    `Created ${ticket.priority} priority support ticket`
  );

  return data;
}

/**
 * Get all support tickets
 */
export async function getAllSupportTickets(filters?: {
  status?: string;
  priority?: string;
  shopId?: string;
}) {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  let query = supabase
    .from('support_tickets')
    .select(`
      *,
      shop:shops(id, shop_name, email)
    `)
    .order('created_at', { ascending: false });

  if (filters?.status) {
    query = query.eq('status', filters.status);
  }
  if (filters?.priority) {
    query = query.eq('priority', filters.priority);
  }
  if (filters?.shopId) {
    query = query.eq('shop_id', filters.shopId);
  }

  const { data, error } = await query;
  if (error) throw error;

  return data || [];
}

/**
 * Update support ticket status
 */
export async function updateSupportTicketStatus(
  ticketId: string,
  status: 'open' | 'in_progress' | 'resolved' | 'closed',
  resolution?: string
) {
  const admin = await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  const updates: Record<string, string | null> = {
    status,
    updated_at: new Date().toISOString(),
  };

  if (status === 'resolved' || status === 'closed') {
    updates.resolved_at = new Date().toISOString();
    updates.resolved_by = admin.user_id;
    if (resolution) {
      updates.resolution = resolution;
    }
  }

  const { error } = await supabase
    .from('support_tickets')
    .update(updates)
    .eq('id', ticketId);

  if (error) throw error;

  await logAdminAction(
    'support_ticket_updated',
    'support',
    ticketId,
    { status, resolution },
    `Updated ticket status to ${status}`
  );
}

/**
 * Get communication history for a shop
 */
export async function getShopCommunicationHistory(shopId: string) {
  await requireSuperAdmin();
  const supabase = await createServerClient();
  
  const [emails, notifications, tickets] = await Promise.all([
    supabase
      .from('admin_communications')
      .select('*')
      .contains('recipients', [shopId])
      .order('sent_at', { ascending: false })
      .limit(20),
    
    supabase
      .from('shop_notifications')
      .select('*')
      .eq('shop_id', shopId)
      .order('created_at', { ascending: false })
      .limit(20),
    
    supabase
      .from('support_tickets')
      .select('*')
      .eq('shop_id', shopId)
      .order('created_at', { ascending: false })
      .limit(10),
  ]);
  
  return {
    emails: emails.data || [],
    notifications: notifications.data || [],
    tickets: tickets.data || [],
  };
}
