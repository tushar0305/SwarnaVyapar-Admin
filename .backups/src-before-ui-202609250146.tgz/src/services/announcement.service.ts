'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { requireSuperAdmin, logAdminAction } from './admin-auth.service';
import { success, failure } from '@/lib/utils';
import type { ServiceResult } from '@/types';

export interface PlatformAnnouncement {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'critical' | 'maintenance';
  target_audience: string;
  is_published: boolean;
  published_at: string | null;
  expires_at: string | null;
  created_by: string;
  created_at: string;
}

export interface CreateAnnouncementInput {
  title: string;
  message: string;
  type: 'info' | 'warning' | 'critical' | 'maintenance';
  target_audience?: string;
  is_published?: boolean;
  expires_at?: string;
}

export interface UpdateAnnouncementInput {
  title?: string;
  message?: string;
  type?: 'info' | 'warning' | 'critical' | 'maintenance';
  target_audience?: string;
  is_published?: boolean;
  expires_at?: string;
}

/**
 * Get all announcements with filters
 */
export async function getAllAnnouncements(filters?: {
  published?: boolean;
  type?: string;
  search?: string;
  limit?: number;
}) {
  await requireSuperAdmin();
  const supabase = await createServerClient();

  let query = supabase
    .from('platform_announcements')
    .select('*')
    .order('created_at', { ascending: false });

  if (filters?.published !== undefined) {
    query = query.eq('is_published', filters.published);
  }

  if (filters?.type && filters.type !== 'all') {
    query = query.eq('type', filters.type);
  }

  if (filters?.search) {
    query = query.or(`title.ilike.%${filters.search}%,message.ilike.%${filters.search}%`);
  }

  if (filters?.limit) {
    query = query.limit(filters.limit);
  }

  const { data, error } = await query;

  if (error) throw error;
  return data as PlatformAnnouncement[];
}

/**
 * Get single announcement by ID
 */
export async function getAnnouncementById(id: string) {
  await requireSuperAdmin();
  const supabase = await createServerClient();

  const { data, error } = await supabase
    .from('platform_announcements')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;
  return data as PlatformAnnouncement;
}

/**
 * Create new announcement
 */
export async function createAnnouncement(
  input: CreateAnnouncementInput
): Promise<ServiceResult<PlatformAnnouncement>> {
  try {
    const adminId = await requireSuperAdmin();
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('platform_announcements')
      .insert({
        title: input.title,
        message: input.message,
        type: input.type,
        target_audience: input.target_audience || 'all',
        is_published: input.is_published ?? false,
        published_at: input.is_published ? new Date().toISOString() : null,
        expires_at: input.expires_at,
        created_by: adminId,
      })
      .select()
      .single();

    if (error) throw error;

    // Audit trail
    await logAdminAction(
      'announcement_created',
      'announcement',
      data.id,
      { title: input.title, type: input.type, is_published: input.is_published },
      'Platform announcement created'
    );

    revalidatePath('/announcements');
    return success(data as PlatformAnnouncement);
  } catch (error: any) {
    return failure(error.message || 'Failed to create announcement');
  }
}

/**
 * Update announcement
 */
export async function updateAnnouncement(
  id: string,
  input: UpdateAnnouncementInput
): Promise<ServiceResult<PlatformAnnouncement>> {
  try {
    await requireSuperAdmin();
    const supabase = await createServerClient();

    // If publishing for first time, set published_at
    const updateData: any = { ...input };
    if (input.is_published && !updateData.published_at) {
      const existing = await getAnnouncementById(id);
      if (!existing.is_published) {
        updateData.published_at = new Date().toISOString();
      }
    }

    const { data, error } = await supabase
      .from('platform_announcements')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Audit trail
    await logAdminAction(
      'announcement_updated',
      'announcement',
      data.id,
      { title: data.title, changes: input },
      'Platform announcement updated'
    );

    revalidatePath('/announcements');
    return success(data as PlatformAnnouncement);
  } catch (error: any) {
    return failure(error.message || 'Failed to update announcement');
  }
}

/**
 * Publish or unpublish announcement
 */
export async function toggleAnnouncementPublish(
  id: string,
  publish: boolean
): Promise<ServiceResult<PlatformAnnouncement>> {
  try {
    await requireSuperAdmin();
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('platform_announcements')
      .update({
        is_published: publish,
        published_at: publish ? new Date().toISOString() : null,
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Audit trail
    await logAdminAction(
      publish ? 'announcement_published' : 'announcement_unpublished',
      'announcement',
      data.id,
      { title: data.title },
      `Announcement ${publish ? 'published' : 'unpublished'}`
    );

    revalidatePath('/announcements');
    return success(data as PlatformAnnouncement);
  } catch (error: any) {
    return failure(error.message || 'Failed to toggle announcement');
  }
}

/**
 * Delete announcement
 */
export async function deleteAnnouncement(id: string): Promise<ServiceResult<void>> {
  try {
    await requireSuperAdmin();
    const supabase = await createServerClient();

    // Get announcement info for audit
    const announcement = await getAnnouncementById(id);

    const { error } = await supabase
      .from('platform_announcements')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Audit trail
    await logAdminAction(
      'announcement_deleted',
      'announcement',
      id,
      { title: announcement.title, type: announcement.type },
      'Platform announcement deleted'
    );

    revalidatePath('/announcements');
    return success(undefined);
  } catch (error: any) {
    return failure(error.message || 'Failed to delete announcement');
  }
}

/**
 * Get announcement statistics
 */
export async function getAnnouncementStatistics() {
  await requireSuperAdmin();
  const supabase = await createServerClient();

  const { data: announcements } = await supabase
    .from('platform_announcements')
    .select('id, is_published, expires_at, type');

  const items = announcements || [];
  const now = new Date();

  const published = items.filter((a) => a.is_published).length;
  const active = items.filter(
    (a) => a.is_published && (!a.expires_at || new Date(a.expires_at) > now)
  ).length;
  const expired = items.filter(
    (a) => a.expires_at && new Date(a.expires_at) <= now
  ).length;
  const critical = items.filter((a) => a.type === 'critical').length;

  return {
    total: items.length,
    published,
    draft: items.length - published,
    active,
    expired,
    critical,
  };
}
