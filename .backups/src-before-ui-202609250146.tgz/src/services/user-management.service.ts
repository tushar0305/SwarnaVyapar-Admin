'use server';

import { getServiceRoleClient } from '@/lib/supabase/admin';
import { requireSuperAdmin, requireAdminPermission, logAdminAction } from './admin-auth.service';
import { success, failure } from '@/lib/utils';
import type { ServiceResult } from '@/types';

/**
 * Get all users across shops with optional filters
 */
export async function getAllUsers(filters?: {
  shopId?: string;
  role?: string;
  status?: 'active' | 'disabled';
  search?: string;
  limit?: number;
  offset?: number;
}) {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  let query = supabase
    .from('user_shop_roles')
    .select(`
      *,
      shop:shops (
        id,
        shop_name,
        gst_number
      )
    `, { count: 'exact' })
    .order('created_at', { ascending: false });

  if (filters?.shopId) {
    query = query.eq('shop_id', filters.shopId);
  }

  if (filters?.role) {
    query = query.eq('role', filters.role);
  }

  if (filters?.status === 'active') {
    query = query.eq('is_active', true);
  } else if (filters?.status === 'disabled') {
    query = query.eq('is_active', false);
  }

  if (filters?.search) {
    query = query.or(`user_id.ilike.%${filters.search}%`);
  }

  if (filters?.limit) {
    query = query.limit(filters.limit);
  }

  if (filters?.offset) {
    query = query.range(filters.offset, filters.offset + (filters.limit || 50) - 1);
  }

  const { data, error, count } = await query;

  if (error) throw error;

  return { data: data || [], count: count || 0 };
}

/**
 * Get user details by ID
 */
export async function getUserById(userId: string) {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  // Get all shop roles for this user
  const { data: roles, error: rolesError } = await supabase
    .from('user_shop_roles')
    .select(`
      *,
      shop:shops (
        id,
        shop_name,
        gst_number,
        is_active
      )
    `)
    .eq('user_id', userId);

  if (rolesError) throw rolesError;

  return {
    user_id: userId,
    roles,
  };
}

/**
 * Disable a user's shop role access
 */
export async function disableUser(
  userShopRoleId: string,
  reason: string
): Promise<ServiceResult<void>> {
  try {
    await requireAdminPermission('manage_users');
    const admin = await requireSuperAdmin();
    const supabase = getServiceRoleClient();

    // Get role details for audit
    const { data: role } = await supabase
      .from('user_shop_roles')
      .select('user_id, shop_id, role')
      .eq('id', userShopRoleId)
      .single();

    // Disable the user-shop role
    const { error: updateError } = await supabase
      .from('user_shop_roles')
      .update({ is_active: false })
      .eq('id', userShopRoleId);

    if (updateError) throw updateError;

    // Audit trail
    await logAdminAction(
      'user_disabled',
      'user',
      role?.user_id || userShopRoleId,
      {
        user_shop_role_id: userShopRoleId,
        shop_id: role?.shop_id,
        role: role?.role,
        reason,
      },
      `Disabled user role: ${reason}`
    );

    return success(undefined);
  } catch (error: any) {
    return failure(error.message || 'Failed to disable user');
  }
}

/**
 * Enable a previously disabled user's shop role access
 */
export async function enableUser(
  userShopRoleId: string,
  notes?: string
): Promise<ServiceResult<void>> {
  try {
    await requireAdminPermission('manage_users');
    const admin = await requireSuperAdmin();
    const supabase = getServiceRoleClient();

    // Get role details for audit
    const { data: role } = await supabase
      .from('user_shop_roles')
      .select('user_id, shop_id, role')
      .eq('id', userShopRoleId)
      .single();

    // Enable the user-shop role
    const { error: updateError } = await supabase
      .from('user_shop_roles')
      .update({ is_active: true })
      .eq('id', userShopRoleId);

    if (updateError) throw updateError;

    // Audit trail
    await logAdminAction(
      'user_enabled',
      'user',
      role?.user_id || userShopRoleId,
      {
        user_shop_role_id: userShopRoleId,
        shop_id: role?.shop_id,
        role: role?.role,
        notes,
      },
      `Enabled user role`
    );

    return success(undefined);
  } catch (error: any) {
    return failure(error.message || 'Failed to enable user');
  }
}

/**
 * Force password reset for a user (requires Auth Admin API)
 * Note: This function is disabled until Supabase Auth Admin API is configured
 */
export async function forcePasswordReset(userId: string): Promise<ServiceResult<void>> {
  try {
    await requireAdminPermission('manage_users');
    const admin = await requireSuperAdmin();
    
    // TODO: Configure Supabase Auth Admin API access
    return failure('Password reset requires Auth Admin API configuration');
    
    // const supabase = getServiceRoleClient();
    // const { data: user } = await supabase.auth.admin.getUserById(userId);
    // if (!user.user?.email) {
    //   return failure('User email not found');
    // }
    // const { error: resetError } = await supabase.auth.resetPasswordForEmail(
    //   user.user.email,
    //   {
    //     redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/reset-password`,
    //   }
    // );
    // if (resetError) throw resetError;
    // await logAdminAction(
    //   'password_reset_forced',
    //   'user',
    //   userId,
    //   {
    //     email: user.user.email,
    //   },
    //   `Forced password reset for ${user.user.email}`
    // );
    // return success(undefined);
  } catch (error: any) {
    return failure(error.message || 'Failed to send password reset');
  }
}

/**
 * Get user statistics
 */
export async function getUserStatistics() {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  const { data: userRoles } = await supabase
    .from('user_shop_roles')
    .select('id, is_active');
  
  const roles = userRoles || [];
  const totalUsers = roles.length;
  const activeUsers = roles.filter((r) => r.is_active).length;
  const disabledUsers = roles.filter((r) => !r.is_active).length;

  return {
    totalUsers,
    activeUsers,
    disabledUsers,
  };
}
