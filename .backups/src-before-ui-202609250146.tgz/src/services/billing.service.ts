'use server';

import { revalidatePath } from 'next/cache';
import { getServiceRoleClient } from '@/lib/supabase/admin';
import { requireSuperAdmin, logAdminAction } from './admin-auth.service';
import { planMonthlyPrice } from '@/lib/plan-prices';

export type BillingEventRow = {
  id: string;
  shop_id: string;
  razorpay_subscription_id: string | null;
  razorpay_payment_id: string | null;
  event_type: string;
  source: string;
  payload: Record<string, unknown> | null;
  created_at: string;
  shop?: { id: string; shop_name: string; email: string | null } | null;
};

/**
 * Payment/billing timeline from Razorpay webhooks (real table: billing_events).
 * RLS is service-only — always use service role after requireSuperAdmin().
 */
export async function getAllPaymentHistory(filters?: {
  eventType?: string;
  startDate?: string;
  endDate?: string;
  limit?: number;
}): Promise<BillingEventRow[]> {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  let query = supabase
    .from('billing_events')
    .select(
      `
      id,
      shop_id,
      razorpay_subscription_id,
      razorpay_payment_id,
      event_type,
      source,
      payload,
      created_at,
      shop:shops(id, shop_name, email)
    `
    )
    .order('created_at', { ascending: false })
    .limit(filters?.limit ?? 100);

  if (filters?.eventType) query = query.eq('event_type', filters.eventType);
  if (filters?.startDate) query = query.gte('created_at', filters.startDate);
  if (filters?.endDate) query = query.lte('created_at', filters.endDate);

  const { data, error } = await query;
  if (error) throw error;
  return (data || []).map((row) => ({
    ...row,
    shop: Array.isArray(row.shop) ? (row.shop[0] ?? null) : row.shop,
  })) as BillingEventRow[];
}

export async function getShopPaymentHistory(shopId: string) {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  const { data, error } = await supabase
    .from('billing_events')
    .select('*')
    .eq('shop_id', shopId)
    .order('created_at', { ascending: false })
    .limit(100);

  if (error) throw error;
  return data || [];
}

function amountFromPayload(payload: Record<string, unknown> | null): number {
  if (!payload) return 0;
  const nested = payload.payload as Record<string, unknown> | undefined;
  const payment =
    (payload.payment as Record<string, unknown> | undefined) ||
    (nested?.payment as Record<string, unknown> | undefined) ||
    (nested?.entity as Record<string, unknown> | undefined);
  const entity =
    (payment?.entity as Record<string, unknown> | undefined) || payment;
  const amountPaise =
    Number(entity?.amount ?? payload.amount ?? nested?.amount ?? 0) || 0;
  // Razorpay amounts are usually paise
  return amountPaise >= 1000 ? amountPaise / 100 : amountPaise;
}

/**
 * Platform billing KPIs from subscriptions + billing_events.
 */
export async function getBillingStatistics() {
  await requireSuperAdmin();
  const supabase = getServiceRoleClient();

  const [subsResult, eventsResult] = await Promise.all([
    supabase.from('subscriptions').select('plan_id, status'),
    supabase
      .from('billing_events')
      .select('event_type, payload, created_at')
      .order('created_at', { ascending: false })
      .limit(500),
  ]);

  const subscriptions = subsResult.data || [];
  const events = eventsResult.data || [];

  const active = subscriptions.filter((s) => s.status === 'active');
  const mrr = active.reduce((sum, s) => sum + planMonthlyPrice(s.plan_id), 0);

  const paymentLike = events.filter((e) =>
    /payment|charged|invoice\.paid|captured/i.test(e.event_type)
  );
  const refundLike = events.filter((e) => /refund/i.test(e.event_type));
  const failedLike = events.filter((e) =>
    /failed|halted|unpaid/i.test(e.event_type)
  );

  const totalRevenue = paymentLike.reduce(
    (sum, e) => sum + amountFromPayload(e.payload as Record<string, unknown>),
    0
  );
  const totalRefunds = refundLike.reduce(
    (sum, e) => sum + amountFromPayload(e.payload as Record<string, unknown>),
    0
  );

  return {
    totalRevenue,
    totalRefunds,
    netRevenue: totalRevenue - totalRefunds,
    activeSubscriptions: active.length,
    mrr,
    avgRevenuePerSubscription: active.length > 0 ? mrr / active.length : 0,
    failedPayments: failedLike.length,
    eventCount: events.length,
  };
}

/** Local plan override. Does not call Razorpay. Inserts a row when the shop has none. */
export async function setShopPlan(input: {
  shopId: string;
  planId: 'free' | 'pro' | 'business';
  status?: 'active' | 'past_due' | 'canceled' | 'trialing' | 'unpaid';
  reason: string;
}) {
  const admin = await requireSuperAdmin();
  if (!admin.permissions.manage_shops && !admin.permissions.system_settings) {
    throw new Error('Unauthorized');
  }
  if (!input.reason.trim()) throw new Error('A reason is required');

  const supabase = getServiceRoleClient();
  const now = new Date().toISOString();
  const status = input.status ?? 'active';
  const patch = {
    plan_id: input.planId,
    status,
    updated_at: now,
  };

  const { data: existing, error: readError } = await supabase
    .from('subscriptions')
    .select('id')
    .eq('shop_id', input.shopId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();
  if (readError) throw readError;

  let id = existing?.id as string | undefined;
  if (id) {
    const { error } = await supabase.from('subscriptions').update(patch).eq('id', id);
    if (error) throw error;
  } else {
    const { data, error } = await supabase
      .from('subscriptions')
      .insert({
        shop_id: input.shopId,
        ...patch,
        current_period_start: now,
      })
      .select('id')
      .single();
    if (error) throw error;
    id = data.id;
  }

  await logAdminAction(
    'subscription_plan_set',
    'subscription',
    id ?? input.shopId,
    { shopId: input.shopId, planId: input.planId, status },
    input.reason.trim()
  );

  revalidatePath('/subscriptions');
  revalidatePath('/overview');
  revalidatePath(`/shops/${input.shopId}`);
  return { id };
}
