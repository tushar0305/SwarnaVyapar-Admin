import { Flag, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  getAllFeatureFlags,
  getFeatureFlagsStatistics,
} from '@/services/feature-flags.service';
import { CreateFeatureFlag } from './_components/create-feature-flag';
import { FeatureActions } from './_components/feature-actions';

export default async function FeaturesPage() {
  const [flags, stats] = await Promise.all([
    getAllFeatureFlags(),
    getFeatureFlagsStatistics(),
  ]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Feature Flags</h1>
          <p className="text-gray-600 mt-1">
            Control feature rollouts and manage shop-specific overrides
          </p>
        </div>
        <CreateFeatureFlag />
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Total Flags
            </CardTitle>
            <Flag className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Enabled Globally
            </CardTitle>
            <TrendingUp className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {stats.enabled_globally}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Disabled Globally
            </CardTitle>
            <TrendingDown className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-600">
              {stats.disabled_globally}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Shop Overrides
            </CardTitle>
            <Flag className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-admin-600">
              {stats.active_overrides}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feature Flags Table */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Flags</CardTitle>
        </CardHeader>
        <CardContent>
          {flags.length === 0 ? (
            <div className="text-center py-12">
              <Flag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 font-medium">No feature flags found</p>
              <p className="text-sm text-gray-500 mt-1">
                Create your first feature flag to control feature rollouts
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Feature
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Key
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Rollout
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {flags.map((flag) => (
                    <tr key={flag.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-medium text-gray-900">{flag.name}</p>
                          {flag.description && (
                            <p className="text-sm text-gray-500 mt-1">
                              {flag.description}
                            </p>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                          {flag.feature_key}
                        </code>
                      </td>
                      <td className="px-6 py-4">
                        {flag.is_enabled_globally ? (
                          <Badge variant="success" className="gap-1">
                            <div className="w-2 h-2 rounded-full bg-green-500" />
                            Enabled
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="gap-1">
                            <div className="w-2 h-2 rounded-full bg-gray-400" />
                            Disabled
                          </Badge>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div
                              className="h-2 rounded-full bg-admin-500"
                              style={{ width: `${flag.rollout_percentage}%` }}
                            />
                          </div>
                          <span className="text-sm text-gray-600">
                            {flag.rollout_percentage}%
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <FeatureActions flag={flag} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
