import { MessageSquare, Mail, Bell, Users, AlertCircle, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { getAllSupportTickets } from '@/services/communication.service';
import { getOnboardingStatistics } from '@/services/onboarding.service';
import { BroadcastMessageDialog } from './_components/broadcast-message';
import { CreateTicketDialog } from './_components/create-ticket';
import { TicketStatusControl } from './_components/ticket-status-control';
import Link from 'next/link';

const priorityColors = {
  low: 'bg-gray-100 text-gray-700',
  medium: 'bg-blue-100 text-blue-700',
  high: 'bg-orange-100 text-orange-700',
  urgent: 'bg-red-100 text-red-700',
};

const statusColors = {
  open: 'bg-yellow-100 text-yellow-700',
  in_progress: 'bg-blue-100 text-blue-700',
  resolved: 'bg-green-100 text-green-700',
  closed: 'bg-gray-100 text-gray-700',
};

export default async function CommunicationsPage() {
  let tickets: Awaited<ReturnType<typeof getAllSupportTickets>> = [];
  let onboardingStats = {
    total: 0,
    completed: 0,
    inProgress: 0,
    notStarted: 0,
    needsHelp: 0,
    avgProgress: 0,
  };
  try {
    tickets = await getAllSupportTickets();
  } catch {
    tickets = [];
  }
  try {
    onboardingStats = await getOnboardingStatistics();
  } catch {
    /* optional advanced tables */
  }

  const openTickets = tickets.filter((t: { status?: string }) => t.status === 'open').length;
  const urgentTickets = tickets.filter((t: { priority?: string }) => t.priority === 'urgent').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Communications & Support</h1>
        <p className="text-gray-600 mt-1">
          Manage shop communications, onboarding, and support tickets
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Open Tickets
            </CardTitle>
            <MessageSquare className="w-4 h-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{openTickets}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Urgent Issues
            </CardTitle>
            <AlertCircle className="w-4 h-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{urgentTickets}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Onboarding Progress
            </CardTitle>
            <Users className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-admin-600">
              {Math.round(onboardingStats.avgProgress)}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Need Help
            </CardTitle>
            <AlertCircle className="w-4 h-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {onboardingStats.needsHelp}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Onboarding Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2">
              <Users className="w-5 h-5 text-admin-600" />
              Activation overview
            </span>
            <Link href="/activation" className="text-sm font-normal text-admin-700 hover:underline">
              Open list →
            </Link>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-3xl font-bold text-green-600">
                {onboardingStats.completed}
              </p>
              <p className="text-sm text-gray-600 mt-1">Activated</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-3xl font-bold text-blue-600">
                {onboardingStats.inProgress}
              </p>
              <p className="text-sm text-gray-600 mt-1">In Progress</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-3xl font-bold text-gray-600">
                {onboardingStats.notStarted}
              </p>
              <p className="text-sm text-gray-600 mt-1">Not Started</p>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <p className="text-3xl font-bold text-yellow-600">
                {onboardingStats.needsHelp}
              </p>
              <p className="text-sm text-gray-600 mt-1">Needs Assistance</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <BroadcastMessageDialog />
            <Button className="w-full gap-2" variant="outline" asChild>
              <Link href="/announcements">
                <Bell className="w-4 h-4" />
                Create Announcement
              </Link>
            </Button>
            <CreateTicketDialog />
          </div>
        </CardContent>
      </Card>

      {/* Support Tickets */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Support Tickets</CardTitle>
            <Button variant="outline" size="sm">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {tickets.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No support tickets yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {tickets.slice(0, 20).map((ticket: any) => (
                <div
                  key={ticket.id}
                  className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between p-4 border border-gray-200 rounded-lg"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-medium text-gray-900">{ticket.subject}</h3>
                      <Badge className={priorityColors[ticket.priority as keyof typeof priorityColors]}>
                        {ticket.priority}
                      </Badge>
                      <Badge className={statusColors[ticket.status as keyof typeof statusColors]}>
                        {ticket.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">
                      {ticket.shop?.shop_name || 'Unknown Shop'}
                    </p>
                    <p className="text-sm text-gray-500 mt-1 line-clamp-2 whitespace-pre-wrap">
                      {ticket.description}
                    </p>
                    {ticket.resolution ? (
                      <p className="text-sm text-green-700 mt-1">
                        Reply: {ticket.resolution}
                      </p>
                    ) : null}
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(ticket.created_at).toLocaleString()}
                    </p>
                  </div>
                  <TicketStatusControl
                    ticketId={ticket.id}
                    status={ticket.status}
                    resolution={ticket.resolution}
                  />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
