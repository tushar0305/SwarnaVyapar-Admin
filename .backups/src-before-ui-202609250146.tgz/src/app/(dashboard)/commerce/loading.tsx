export default function CommerceLoading() {
  return <div className="mx-auto h-96 max-w-6xl animate-pulse rounded-xl bg-gray-200" />;
}
