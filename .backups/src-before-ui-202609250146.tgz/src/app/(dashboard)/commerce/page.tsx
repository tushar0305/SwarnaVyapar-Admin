import Link from 'next/link';
import { getCommandCenter } from '@/services/command-center.service';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { Metric } from '../_components/metric';

export const dynamic = 'force-dynamic';

export default async function CommercePage() {
  const data = await getCommandCenter();
  const rows = [...data.tenants].sort((a, b) => b.gmv30d - a.gmv30d);

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-gray-950">Commerce</h1>
        <p className="mt-1 text-sm text-gray-600">
          What shops sold and collected in the last 30 days. This is customer money, not SwarnaVyapar revenue.
        </p>
      </div>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          label="Invoice value"
          value={formatCurrency(data.commerce.gmv30d)}
          scope={`${formatNumber(data.commerce.invoices30d)} invoices · today ${formatNumber(data.commerce.invoicesToday)}`}
        />
        <Metric
          label="Collected"
          value={formatCurrency(data.commerce.collected30d)}
          scope="Payments in the last 30 days"
        />
        <Metric
          label="Balance due"
          value={formatCurrency(data.commerce.balanceDue)}
          scope="Still unpaid on open invoices"
          tone={data.commerce.balanceDue > 0 ? 'attention' : 'default'}
        />
        <Metric
          label="SwarnaVyapar MRR"
          value={formatCurrency(data.subscriptions.mrrInr)}
          scope="Active plan prices, separate from shop sales"
          href="/billing"
        />
      </section>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-4 py-3 font-medium">Shop</th>
                <th className="px-4 py-3 font-medium">Plan</th>
                <th className="px-4 py-3 text-right font-medium">Sales 30d</th>
                <th className="px-4 py-3 text-right font-medium">Collected</th>
                <th className="px-4 py-3 text-right font-medium">Due</th>
                <th className="px-4 py-3 text-right font-medium">Invoices</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {rows.map((shop) => (
                <tr key={shop.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <Link href={`/shops/${shop.id}`} className="font-medium text-gray-950 hover:text-admin-700">
                      {shop.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {shop.plan}
                    <span className="block text-xs text-gray-400">{shop.subscriptionStatus}</span>
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">{formatCurrency(shop.gmv30d)}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{formatCurrency(shop.collected30d)}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{formatCurrency(shop.balanceDue)}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{shop.invoices30d}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
