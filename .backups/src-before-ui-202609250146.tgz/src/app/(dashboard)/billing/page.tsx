import { DollarSign, TrendingUp, CreditCard, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  getAllPaymentHistory,
  getBillingStatistics,
} from '@/services/billing.service';

export default async function BillingPage() {
  let payments: Awaited<ReturnType<typeof getAllPaymentHistory>> = [];
  let stats = {
    totalRevenue: 0,
    totalRefunds: 0,
    netRevenue: 0,
    activeSubscriptions: 0,
    mrr: 0,
    avgRevenuePerSubscription: 0,
    failedPayments: 0,
    eventCount: 0,
  };

  try {
    [payments, stats] = await Promise.all([
      getAllPaymentHistory({ limit: 50 }),
      getBillingStatistics(),
    ]);
  } catch (e) {
    console.error('Billing page load failed:', e);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Billing & Payments</h1>
        <p className="text-gray-600 mt-1">
          Razorpay webhook events and subscription MRR (from plan prices)
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Recorded payment volume
            </CardTitle>
            <DollarSign className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ₹{stats.totalRevenue.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              From billing_events payloads (approx.)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              MRR
            </CardTitle>
            <TrendingUp className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-admin-600">
              ₹{stats.mrr.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Active plans × list price
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Active subscriptions
            </CardTitle>
            <CreditCard className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {stats.activeSubscriptions}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Avg ₹{Math.round(stats.avgRevenuePerSubscription)} / sub
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Failed / unpaid signals
            </CardTitle>
            <AlertTriangle className="w-4 h-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {stats.failedPayments}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {stats.eventCount} recent events scanned
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent billing events</CardTitle>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No billing_events yet</p>
              <p className="text-sm text-gray-500 mt-1">
                Events appear when Razorpay webhooks hit the main app
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Shop
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Event
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Source
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Payment ID
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {payments.map((event) => (
                    <tr key={event.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {event.shop?.shop_name || 'Unknown'}
                          </p>
                          <p className="text-xs text-gray-500">
                            {event.shop?.email}
                          </p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="secondary">{event.event_type}</Badge>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {event.source}
                      </td>
                      <td className="px-4 py-3 text-sm font-mono text-gray-600">
                        {event.razorpay_payment_id || '—'}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {new Date(event.created_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
