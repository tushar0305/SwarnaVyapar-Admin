import Link from 'next/link';
import { cn } from '@/lib/utils';

export function Metric({
  label,
  value,
  scope,
  href,
  tone = 'default',
}: {
  label: string;
  value: string;
  scope: string;
  href?: string;
  tone?: 'default' | 'attention';
}) {
  const body = (
    <div
      className={cn(
        'rounded-xl border bg-white p-5',
        tone === 'attention' ? 'border-amber-300' : 'border-gray-200'
      )}
    >
      <p className="text-xs font-medium uppercase tracking-wide text-gray-500">{label}</p>
      <p className="mt-2 text-2xl font-semibold tracking-tight text-gray-950">{value}</p>
      <p className="mt-1 text-xs text-gray-500">{scope}</p>
    </div>
  );
  if (!href) return body;
  return (
    <Link href={href} className="block transition-colors hover:bg-gray-50">
      {body}
    </Link>
  );
}
