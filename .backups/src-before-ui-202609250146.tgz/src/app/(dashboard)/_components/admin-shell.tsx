'use client';

import { useState } from 'react';
import { AdminHeader } from './admin-header';
import { AdminNav } from './admin-nav';

export function AdminShell({
  adminName,
  children,
}: {
  adminName: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f6f5f3]">
      <AdminHeader name={adminName} onMenu={() => setOpen(true)} />
      <div className="flex">
        <AdminNav open={open} onClose={() => setOpen(false)} />
        <main className="min-w-0 flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
