'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Store,
  Users,
  Sliders,
  Flag,
  Activity,
  BarChart3,
  Bell,
  Settings,
  Shield,
  CreditCard,
  MessageSquare,
  IndianRupee,
  TrendingUp,
  Wallet,
  ShoppingBag,
  X,
} from 'lucide-react';

const groups = [
  {
    label: 'Command',
    items: [
      { name: 'Overview', href: '/overview', icon: LayoutDashboard },
      { name: 'Shops', href: '/shops', icon: Store },
      { name: 'Users', href: '/users', icon: Users },
      { name: 'Activation', href: '/activation', icon: TrendingUp },
    ],
  },
  {
    label: 'Money',
    items: [
      { name: 'Commerce', href: '/commerce', icon: ShoppingBag },
      { name: 'Credits', href: '/credits', icon: Wallet },
      { name: 'Billing', href: '/billing', icon: IndianRupee },
      { name: 'Subscriptions', href: '/subscriptions', icon: CreditCard },
    ],
  },
  {
    label: 'Product',
    items: [
      { name: 'Communications', href: '/communications', icon: MessageSquare },
      { name: 'Limits', href: '/limits', icon: Sliders },
      { name: 'Features', href: '/features', icon: Flag },
      { name: 'Announcements', href: '/announcements', icon: Bell },
    ],
  },
  {
    label: 'Platform',
    items: [
      { name: 'Health', href: '/health', icon: Activity },
      { name: 'Analytics', href: '/analytics', icon: BarChart3 },
      { name: 'Audit log', href: '/audit', icon: Shield },
      { name: 'Settings', href: '/settings', icon: Settings },
    ],
  },
];

export function AdminNav({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const pathname = usePathname();

  const nav = (
    <nav className="flex h-full flex-col gap-6 overflow-y-auto p-4">
      {groups.map((group) => (
        <div key={group.label}>
          <p className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-gray-400">
            {group.label}
          </p>
          <div className="space-y-0.5">
            {group.items.map((item) => {
              const isActive =
                pathname === item.href || pathname?.startsWith(`${item.href}/`);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onClose}
                  className={cn(
                    'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-admin-100 text-admin-900'
                      : 'text-gray-700 hover:bg-gray-100'
                  )}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {item.name}
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );

  return (
    <>
      <aside className="hidden w-60 shrink-0 border-r border-gray-200 bg-white lg:block lg:min-h-[calc(100vh-64px)]">
        {nav}
      </aside>
      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close menu"
            className="absolute inset-0 bg-black/40"
            onClick={onClose}
          />
          <aside className="relative flex h-full w-72 flex-col bg-white shadow-xl">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <p className="text-sm font-semibold text-gray-900">Menu</p>
              <button type="button" onClick={onClose} aria-label="Close menu">
                <X className="h-5 w-5" />
              </button>
            </div>
            {nav}
          </aside>
        </div>
      ) : null}
    </>
  );
}
