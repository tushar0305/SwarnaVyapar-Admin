import { Settings, Shield, Database, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { requireSuperAdmin } from '@/services/admin-auth.service';
import { createServerClient } from '@/lib/supabase/server';

async function getAdminInfo() {
  const adminId = await requireSuperAdmin();
  const supabase = await createServerClient();
  
  const { data: admin } = await supabase
    .from('super_admins')
    .select('*')
    .eq('id', adminId)
    .single();
    
  return admin;
}

async function getPlatformInfo() {
  const supabase = await createServerClient();
  
  const [shopsCount, usersCount, adminsCount] = await Promise.all([
    supabase.from('shops').select('id', { count: 'exact', head: true }),
    supabase.from('user_shop_roles').select('id', { count: 'exact', head: true }),
    supabase.from('super_admins').select('id', { count: 'exact', head: true }),
  ]);
  
  return {
    totalShops: shopsCount.count || 0,
    totalUsers: usersCount.count || 0,
    totalAdmins: adminsCount.count || 0,
  };
}

export default async function SettingsPage() {
  const [admin, platformInfo] = await Promise.all([
    getAdminInfo(),
    getPlatformInfo(),
  ]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Admin Settings</h1>
        <p className="text-gray-600 mt-1">
          Configure admin panel settings and view platform information
        </p>
      </div>

      {/* Admin Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-admin-600" />
            Super Admin Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">User ID</p>
                <p className="font-mono text-sm">{admin?.user_id}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Role</p>
                <Badge variant="success">Super Admin</Badge>
              </div>
              <div>
                <p className="text-sm text-gray-500">Created At</p>
                <p className="text-sm">{new Date(admin?.created_at).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Last Login</p>
                <p className="text-sm">
                  {admin?.last_login_at
                    ? new Date(admin.last_login_at).toLocaleString()
                    : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Platform Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-admin-600" />
            Platform Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-admin-600">
                {platformInfo.totalShops}
              </p>
              <p className="text-sm text-gray-600 mt-1">Total Shops</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-admin-600">
                {platformInfo.totalUsers}
              </p>
              <p className="text-sm text-gray-600 mt-1">Total Users</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-admin-600">
                {platformInfo.totalAdmins}
              </p>
              <p className="text-sm text-gray-600 mt-1">Super Admins</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-admin-600" />
            System Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Admin Panel Version</span>
              <span className="text-sm font-medium">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Database</span>
              <Badge variant="success">Connected</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Authentication</span>
              <Badge variant="success">Active</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Audit Logging</span>
              <Badge variant="success">Enabled</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
