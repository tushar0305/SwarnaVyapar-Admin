import Link from 'next/link';
import { AlertTriangle, CheckCircle, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getActivationSnapshot, type ActivationRow } from '@/services/onboarding.service';
import { formatDate } from '@/lib/utils';

const COHORT_LABEL: Record<ActivationRow['primary'], string> = {
  never_started: 'Never started',
  stalled_billing: 'Stocked, never billed',
  activated: 'Activated',
  quiet: 'Quiet after billing',
};

function ShopList({
  title,
  hint,
  rows,
}: {
  title: string;
  hint: string;
  rows: ActivationRow[];
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">
          {title}{' '}
          <span className="text-gray-500 font-normal">({rows.length})</span>
        </CardTitle>
        <p className="text-sm text-gray-500">{hint}</p>
      </CardHeader>
      <CardContent>
        {rows.length === 0 ? (
          <p className="text-sm text-gray-500">None in this window.</p>
        ) : (
          <div className="space-y-2">
            {rows.slice(0, 25).map((row) => (
              <Link
                key={row.shopId}
                href={`/shops/${row.shopId}/analytics`}
                className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100"
              >
                <div>
                  <p className="text-sm font-medium text-gray-900">{row.shopName}</p>
                  <p className="text-xs text-gray-500">
                    {row.counts.invoices} invoices · {row.counts.customers} customers ·{' '}
                    {row.counts.inventory} stock
                    {row.planId ? ` · ${row.planId}` : ''}
                  </p>
                </div>
                <div className="text-right space-y-1">
                  <Badge variant="secondary">{COHORT_LABEL[row.primary]}</Badge>
                  <p className="text-xs text-gray-500">
                    {formatDate(row.createdAt)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default async function ActivationPage() {
  const snap = await getActivationSnapshot();
  const neverStarted = snap.shops.filter((s) => s.primary === 'never_started');
  const stalled = snap.shops.filter((s) => s.primary === 'stalled_billing');
  const quiet = snap.shops.filter((s) => s.primary === 'quiet');
  const upgradeReady = snap.shops.filter((s) => s.upgradeReady);
  const whatsappOff = snap.shops.filter((s) => s.tags.includes('whatsapp_off'));
  const needsHelp = snap.shops.filter((s) => s.needsAssistance);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Shop activation</h1>
        <p className="text-gray-600 mt-1">
          First invoice is activated. Counts come from live shop tables, not session replay.
        </p>
        {snap.truncated ? (
          <p className="text-xs text-amber-700 mt-2">
            Showing the {snap.shops.length} newest shops of {snap.stats.total}.
          </p>
        ) : null}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Activated
            </CardTitle>
            <CheckCircle className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{snap.stats.completed}</p>
            <p className="text-xs text-gray-500 mt-1">At least one invoice</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Never billed
            </CardTitle>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-amber-600">
              {snap.stats.inProgress + snap.stats.notStarted}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {snap.stats.needsHelp} older than 7 days
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Upgrade-ready
            </CardTitle>
            <TrendingUp className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{upgradeReady.length}</p>
            <p className="text-xs text-gray-500 mt-1">Free shops at ≥80% of a cap</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Core progress
            </CardTitle>
            <Clock className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{Math.round(snap.stats.avgProgress)}%</p>
            <p className="text-xs text-gray-500 mt-1">GST, customer, stock, bill, WhatsApp</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ShopList
          title="Need help"
          hint="No invoice after 7 days. Call or WhatsApp the owner."
          rows={needsHelp}
        />
        <ShopList
          title="Stocked, never billed"
          hint="They added inventory or customers but never made a bill."
          rows={stalled}
        />
        <ShopList
          title="Never started"
          hint="Shop exists, nothing else."
          rows={neverStarted}
        />
        <ShopList
          title="Quiet after billing"
          hint="Billed at least once, then silent for 14+ days."
          rows={quiet}
        />
        <ShopList
          title="Upgrade-ready"
          hint="Free plan near customer, stock, loan, or scheme cap."
          rows={upgradeReady}
        />
        <ShopList
          title="Billed, WhatsApp off"
          hint="They can invoice but cannot share from the counter."
          rows={whatsappOff}
        />
      </div>
    </div>
  );
}
