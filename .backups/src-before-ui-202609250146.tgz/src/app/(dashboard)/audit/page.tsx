import { Suspense } from 'react';
import { getAuditLog } from '@/services/admin-auth.service';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { formatDateTime } from '@/lib/utils';
import { Activity, Search } from 'lucide-react';

interface AuditPageProps {
  searchParams: Promise<{
    action?: string;
    page?: string;
    search?: string;
  }>;
}

type AuditFilters = Awaited<AuditPageProps['searchParams']>;

async function AuditLogTable({ searchParams }: { searchParams: AuditFilters }) {
  const page = Number(searchParams?.page) || 1;
  const limit = 50;
  const offset = (page - 1) * limit;

  const { data: logs, count } = await getAuditLog({
    action: searchParams?.action,
    search: searchParams?.search,
    limit,
    offset,
  });

  const totalPages = count ? Math.ceil(count / limit) : 0;

  const getActionColor = (action: string) => {
    switch (action) {
      case 'shop_suspended':
        return 'destructive';
      case 'shop_unsuspended':
        return 'default';
      case 'limit_updated':
        return 'secondary';
      case 'feature_toggled':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const getActionLabel = (action: string) => {
    return action
      .split('_')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  if (!logs || logs.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Activity className="h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-600">No audit entries found</p>
            <p className="text-sm text-gray-500 mt-2">
              Admin actions will appear here
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Timestamp
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Admin
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Action
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Target
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Details
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {logs.map((log: any) => (
                  <tr key={log.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatDateTime(log.created_at)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {log.admin?.name || 'System'}
                      </div>
                      <div className="text-sm text-gray-500">
                        {log.admin?.email}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge variant={getActionColor(log.action)}>
                        {getActionLabel(log.action)}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="font-medium">{log.target_type}</div>
                      {log.metadata?.shopName && (
                        <div className="text-gray-500 text-xs">
                          {log.metadata.shopName}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600 max-w-md">
                      <p className="truncate">{log.details}</p>
                      {log.metadata?.reason && (
                        <p className="text-xs text-gray-500 mt-1">
                          Reason: {log.metadata.reason}
                        </p>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Showing {offset + 1} to {Math.min(offset + limit, count || 0)} of{' '}
            {count} entries
          </p>
          <div className="flex gap-2">
            {page > 1 && (
              <a
                href={`/audit?page=${page - 1}${
                  searchParams?.action ? `&action=${searchParams.action}` : ''
                }${searchParams?.search ? `&search=${searchParams.search}` : ''}`}
                className="px-4 py-2 text-sm border rounded-md hover:bg-gray-50"
              >
                Previous
              </a>
            )}
            <span className="px-4 py-2 text-sm border rounded-md bg-gray-50">
              Page {page} of {totalPages}
            </span>
            {page < totalPages && (
              <a
                href={`/audit?page=${page + 1}${
                  searchParams?.action ? `&action=${searchParams.action}` : ''
                }${searchParams?.search ? `&search=${searchParams.search}` : ''}`}
                className="px-4 py-2 text-sm border rounded-md hover:bg-gray-50"
              >
                Next
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default async function AuditPage({ searchParams }: AuditPageProps) {
  const params = await searchParams;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Audit Log</h1>
        <p className="text-gray-600 mt-2">
          Complete trail of all super admin actions
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter audit log entries</CardDescription>
        </CardHeader>
        <CardContent>
          <form method="get" action="/audit" className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                name="search"
                placeholder="Search details, shop names..."
                defaultValue={params.search}
                className="pl-10"
              />
            </div>
            <select
              name="action"
              defaultValue={params.action || ''}
              className="px-4 py-2 border rounded-md text-sm"
            >
              <option value="">All Actions</option>
              <option value="shop_suspended">Shop Suspended</option>
              <option value="shop_unsuspended">Shop Unsuspended</option>
              <option value="limit_updated">Limit Updated</option>
              <option value="feature_toggled">Feature Toggled</option>
              <option value="subscription_updated">Subscription Updated</option>
            </select>
            <button
              type="submit"
              className="px-6 py-2 bg-admin-600 text-white rounded-md hover:bg-admin-700"
            >
              Apply
            </button>
            {(params.action || params.search) && (
              <a
                href="/audit"
                className="px-6 py-2 border rounded-md hover:bg-gray-50"
              >
                Clear
              </a>
            )}
          </form>
        </CardContent>
      </Card>

      <Suspense
        fallback={
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-gray-600">Loading audit log...</p>
            </CardContent>
          </Card>
        }
      >
        <AuditLogTable searchParams={params} />
      </Suspense>
    </div>
  );
}
