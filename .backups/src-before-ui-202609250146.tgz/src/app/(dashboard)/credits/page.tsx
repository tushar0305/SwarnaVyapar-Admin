import Link from 'next/link';
import { getCommandCenter } from '@/services/command-center.service';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { millicreditsToCredits, millicreditsToInr } from '@/lib/credits';
import { Metric } from '../_components/metric';

export const dynamic = 'force-dynamic';

export default async function CreditsPage() {
  const data = await getCommandCenter();
  const rows = [...data.tenants].sort((a, b) => a.availableMc - b.availableMc);

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-gray-950">Credits</h1>
        <p className="mt-1 text-sm text-gray-600">
          WhatsApp and AI draw from shop wallets. 1 credit is ₹0.50. The low-balance line is ₹50.
        </p>
      </div>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          label="Available"
          value={formatNumber(millicreditsToCredits(data.credits.availableMc))}
          scope={`${formatCurrency(millicreditsToInr(data.credits.availableMc))} left in all wallets`}
          tone={data.credits.emptyWallets > 0 ? 'attention' : 'default'}
        />
        <Metric
          label="Spent, 30 days"
          value={formatNumber(millicreditsToCredits(data.credits.spent30dMc))}
          scope={formatCurrency(millicreditsToInr(data.credits.spent30dMc))}
        />
        <Metric
          label="Empty wallets"
          value={formatNumber(data.credits.emptyWallets)}
          scope={`${data.credits.lowWallets} more are under the ₹50 line`}
        />
        <Metric
          label="Frozen"
          value={formatNumber(data.credits.frozen)}
          scope="Wallets blocked from spend"
        />
      </section>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-4 py-3 font-medium">Shop</th>
                <th className="px-4 py-3 text-right font-medium">Credits</th>
                <th className="px-4 py-3 text-right font-medium">Value</th>
                <th className="px-4 py-3 font-medium">State</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {rows.map((shop) => (
                <tr key={shop.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <Link href={`/shops/${shop.id}`} className="font-medium text-gray-950 hover:text-admin-700">
                      {shop.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">
                    {formatNumber(millicreditsToCredits(shop.availableMc))}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">
                    {formatCurrency(millicreditsToInr(shop.availableMc))}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {shop.frozen ? 'Frozen' : shop.availableMc === 0 ? 'Empty' : shop.lowCredits ? 'Low' : 'Healthy'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
