import { TrendingUp, Users, Store, Activity, Flag, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  getPlatformStats,
  getShopGrowth,
  getUserActivityMetrics,
  getSubscriptionDistribution,
  getRecentActivity,
} from '@/services/analytics.service';
import { getUsageMetrics } from '@/services/shop-analytics.service';

async function safe<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn();
  } catch {
    return fallback;
  }
}

export default async function AnalyticsPage() {
  const emptyDist = { byStatus: [] as { status: string; count: number }[], byPlan: [] as { plan: string; count: number }[] };
  const emptyUsage = {
    totalInvoices: 0,
    totalCustomers: 0,
    totalInventory: 0,
    totalUsers: 0,
    shopCount: 0,
    avgInvoicesPerShop: 0,
    avgCustomersPerShop: 0,
    periodAiTokens: 0,
    periodInvoices: 0,
    periodCustomers: 0,
    totalProducts: 0,
  };

  const [
    platformStats,
    shopGrowth,
    userMetrics,
    subscriptions,
    recentActivity,
    usage,
  ] = await Promise.all([
    safe(() => getPlatformStats(), {
      totalShops: 0,
      activeShops: 0,
      suspendedShops: 0,
      totalUsers: 0,
      totalAuditLogs: 0,
      totalFeatureFlags: 0,
      enabledFeatureFlags: 0,
    }),
    safe(() => getShopGrowth(), []),
    safe(() => getUserActivityMetrics(), {
      totalUserRoles: 0,
      activeUserRoles: 0,
      inactiveUserRoles: 0,
      avgUsersPerShop: 0,
    }),
    safe(() => getSubscriptionDistribution(), emptyDist),
    safe(() => getRecentActivity(), { recentShops: [], recentActions: [] }),
    safe(() => getUsageMetrics(), emptyUsage),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Platform Analytics</h1>
        <p className="text-gray-600 mt-1">
          Usage, growth, and subscription mix
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Total Shops
            </CardTitle>
            <Store className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{platformStats.totalShops}</div>
            <p className="text-xs text-gray-500 mt-1">
              {platformStats.activeShops} active ·{' '}
              {platformStats.suspendedShops} suspended
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Total User Roles
            </CardTitle>
            <Users className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{platformStats.totalUsers}</div>
            <p className="text-xs text-gray-500 mt-1">
              Avg {userMetrics.avgUsersPerShop} per shop
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Feature Flags
            </CardTitle>
            <Flag className="w-4 h-4 text-admin-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {platformStats.totalFeatureFlags}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {platformStats.enabledFeatureFlags} enabled globally
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-admin-600" />
            Usage totals
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-gray-500">Invoices</p>
              <p className="text-2xl font-bold">{usage.totalInvoices}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Customers</p>
              <p className="text-2xl font-bold">{usage.totalCustomers}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Inventory</p>
              <p className="text-2xl font-bold">{usage.totalInventory}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Avg inv / shop</p>
              <p className="text-2xl font-bold">{usage.avgInvoicesPerShop}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-admin-600" />
            User Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-500">Total User Roles</p>
              <p className="text-2xl font-bold text-admin-600">
                {userMetrics.totalUserRoles}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Active</p>
              <p className="text-2xl font-bold text-green-600">
                {userMetrics.activeUserRoles}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Inactive</p>
              <p className="text-2xl font-bold text-gray-600">
                {userMetrics.inactiveUserRoles}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-admin-600" />
            Shop Growth (by month)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {shopGrowth.length === 0 ? (
            <p className="text-sm text-gray-500">No data available</p>
          ) : (
            <div className="space-y-2">
              {shopGrowth.map((item) => (
                <div
                  key={item.month}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded"
                >
                  <span className="text-sm font-medium">{item.month}</span>
                  <span className="text-sm text-admin-600 font-semibold">
                    {item.count} shops
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-admin-600" />
              Subscription status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {subscriptions.byStatus.length === 0 ? (
              <p className="text-sm text-gray-500">No subscriptions found</p>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {subscriptions.byStatus.map((item) => (
                  <div key={item.status} className="text-center">
                    <p className="text-2xl font-bold text-admin-600">
                      {item.count}
                    </p>
                    <p className="text-sm text-gray-500 capitalize">
                      {item.status}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Plan mix</CardTitle>
          </CardHeader>
          <CardContent>
            {subscriptions.byPlan.length === 0 ? (
              <p className="text-sm text-gray-500">No plans</p>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {subscriptions.byPlan.map((item) => (
                  <div key={item.plan} className="text-center">
                    <p className="text-2xl font-bold text-admin-600">
                      {item.count}
                    </p>
                    <p className="text-sm text-gray-500 capitalize">{item.plan}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Shops</CardTitle>
          </CardHeader>
          <CardContent>
            {recentActivity.recentShops.length === 0 ? (
              <p className="text-sm text-gray-500">No recent shops</p>
            ) : (
              <div className="space-y-3">
                {recentActivity.recentShops.map(
                  (shop: { id: string; shop_name: string; created_at: string }) => (
                    <div
                      key={shop.id}
                      className="flex items-center justify-between p-2 hover:bg-gray-50 rounded"
                    >
                      <div>
                        <p className="text-sm font-medium">{shop.shop_name}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(shop.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Admin Actions</CardTitle>
          </CardHeader>
          <CardContent>
            {recentActivity.recentActions.length === 0 ? (
              <p className="text-sm text-gray-500">No recent actions</p>
            ) : (
              <div className="space-y-2">
                {recentActivity.recentActions
                  .slice(0, 5)
                  .map((action: { id: string; action: string; created_at: string }) => (
                    <div
                      key={action.id}
                      className="flex items-center justify-between p-2 hover:bg-gray-50 rounded text-sm"
                    >
                      <span className="font-medium">{action.action}</span>
                      <span className="text-gray-500 text-xs">
                        {new Date(action.created_at).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
