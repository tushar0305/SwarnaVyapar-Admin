export default function OverviewLoading() {
  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="h-16 w-64 animate-pulse rounded-lg bg-gray-200" />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-28 animate-pulse rounded-xl bg-gray-200" />
        ))}
      </div>
      <div className="h-80 animate-pulse rounded-xl bg-gray-200" />
    </div>
  );
}
