import Link from 'next/link';
import { getCommandCenter } from '@/services/command-center.service';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { UpdatedAt } from '../_components/updated-at';
import { millicreditsToCredits, millicreditsToInr } from '@/lib/credits';
import { Metric } from '../_components/metric';

export const dynamic = 'force-dynamic';

export default async function OverviewPage() {
  const data = await getCommandCenter();
  const sellingWithoutPlan = data.tenants.filter(
    (shop) => shop.gmv30d > 0 && shop.subscriptionStatus !== 'active'
  );
  const quietSellers = data.tenants.filter(
    (shop) =>
      shop.gmv30d > 0 &&
      (!shop.lastActivityAt ||
        Date.now() - new Date(shop.lastActivityAt).getTime() > 14 * 86400000)
  );
  const creditInr = millicreditsToInr(data.credits.availableMc);

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-admin-700">
            Today
          </p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-gray-950">
            Control center
          </h1>
          <p className="mt-1 text-sm text-gray-600">
            Shop sales, what we actually bill, and who needs a decision.
          </p>
        </div>
        <p className="text-xs text-gray-500">
          <UpdatedAt iso={data.generatedAt} />
        </p>
      </div>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          label="Shop sales"
          value={formatCurrency(data.commerce.gmv30d)}
          scope="Invoice value, last 30 days, cancelled excluded"
          href="/commerce"
        />
        <Metric
          label="Collected"
          value={formatCurrency(data.commerce.collected30d)}
          scope="Customer payments recorded in 30 days"
          href="/commerce"
        />
        <Metric
          label="Still due"
          value={formatCurrency(data.commerce.balanceDue)}
          scope="Open balance on non-cancelled invoices"
          href="/commerce"
          tone={data.commerce.balanceDue > 0 ? 'attention' : 'default'}
        />
        <Metric
          label="Our MRR"
          value={formatCurrency(data.subscriptions.mrrInr)}
          scope={`${data.subscriptions.active} active paid plan${data.subscriptions.active === 1 ? '' : 's'}`}
          href="/subscriptions"
          tone={sellingWithoutPlan.length > 0 ? 'attention' : 'default'}
        />
      </section>

      <section className="grid gap-4 lg:grid-cols-5">
        <div className="rounded-xl border border-gray-200 bg-white p-5 lg:col-span-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold text-gray-950">
              Selling without a paid plan
            </h2>
            <Link href="/shops" className="text-sm text-admin-700 hover:underline">
              All shops
            </Link>
          </div>
          <p className="mt-1 text-sm text-gray-500">
            {sellingWithoutPlan.length === 0
              ? 'Every shop with sales this month is on an active plan.'
              : `${sellingWithoutPlan.length} shops invoiced in 30 days and are not on an active subscription.`}
          </p>
          <ul className="mt-4 divide-y divide-gray-100">
            {sellingWithoutPlan.slice(0, 6).map((shop) => (
              <li key={shop.id} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <Link
                    href={`/shops/${shop.id}`}
                    className="truncate font-medium text-gray-950 hover:text-admin-700"
                  >
                    {shop.name}
                  </Link>
                  <p className="text-xs text-gray-500">
                    {shop.plan} · {shop.subscriptionStatus}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-medium tabular-nums">{formatCurrency(shop.gmv30d)}</p>
                  <p className="text-xs text-gray-500">
                    {shop.invoices30d} invoice{shop.invoices30d === 1 ? '' : 's'}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="space-y-3 lg:col-span-2">
          <Link
            href="/communications"
            className="block rounded-xl border border-gray-200 bg-white p-5 hover:border-admin-200"
          >
            <p className="text-sm text-gray-500">Open support</p>
            <p className="mt-1 text-2xl font-semibold">{data.ops.openTickets}</p>
            {data.tickets[0] ? (
              <p className="mt-2 truncate text-sm text-gray-700">{data.tickets[0].title}</p>
            ) : (
              <p className="mt-2 text-sm text-gray-500">No open tickets</p>
            )}
          </Link>
          <Link
            href="/credits"
            className="block rounded-xl border border-amber-300 bg-white p-5"
          >
            <p className="text-sm text-gray-500">Credits left</p>
            <p className="mt-1 text-2xl font-semibold">
              {formatNumber(millicreditsToCredits(data.credits.availableMc))}
            </p>
            <p className="mt-2 text-sm text-gray-600">
              {formatCurrency(creditInr)} across wallets · {data.credits.emptyWallets} empty ·{' '}
              {formatNumber(millicreditsToCredits(data.credits.spent30dMc))} spent in 30 days
            </p>
          </Link>
          <Link
            href="/activation"
            className="block rounded-xl border border-gray-200 bg-white p-5 hover:border-admin-200"
          >
            <p className="text-sm text-gray-500">Quiet shops</p>
            <p className="mt-1 text-2xl font-semibold">{data.shops.quiet14d}</p>
            <p className="mt-2 text-sm text-gray-600">
              No activity in 14 days
              {quietSellers.length > 0
                ? ` · ${quietSellers.length} of them sold this month`
                : ''}
            </p>
          </Link>
        </div>
      </section>

      <section className="rounded-xl border border-gray-200 bg-white p-5">
        <h2 className="text-base font-semibold text-gray-950">Product in use</h2>
        <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {[
            ['Invoices, 30d', formatNumber(data.commerce.invoices30d)],
            ['Customers', formatNumber(data.product.customers)],
            ['Inventory', formatNumber(data.product.inventoryItems)],
            ['Catalogue views, 7d', formatNumber(data.product.catalogueEvents7d)],
            ['WhatsApp connected', formatNumber(data.product.whatsappConnected)],
            ['AI calls this month', formatNumber(data.product.aiUsageMonth)],
          ].map(([label, value]) => (
            <div key={label}>
              <p className="text-xs text-gray-500">{label}</p>
              <p className="mt-1 text-lg font-semibold tabular-nums">{value}</p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-gray-500">
          {data.shops.total} shops · {data.shops.new30d} created in 30 days ·{' '}
          {data.shops.suspended} suspended · cron issues in 7 days:{' '}
          {data.ops.cronFailures7d} · WhatsApp failures: {data.product.whatsappFailed}
        </p>
      </section>
    </div>
  );
}
