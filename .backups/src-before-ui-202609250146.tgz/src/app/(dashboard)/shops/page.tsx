import { Suspense } from 'react';
import Link from 'next/link';
import { getAllShops } from '@/services/shop-management.service';
import { ShopsTable } from './_components/shops-table';

export const dynamic = 'force-dynamic';

async function ShopsData({
  q,
  status,
}: {
  q?: string;
  status?: 'active' | 'suspended' | 'all';
}) {
  const { shops, total } = await getAllShops({
    limit: 50,
    search: q,
    status: status && status !== 'all' ? status : undefined,
  });

  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600">
        Showing {shops.length} of {total} shops
      </p>
      <ShopsTable shops={shops} />
    </div>
  );
}

export default async function ShopsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string }>;
}) {
  const params = await searchParams;
  const q = params.q?.trim() || undefined;
  const status =
    params.status === 'active' || params.status === 'suspended' ? params.status : 'all';

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-gray-950">Shops</h1>
          <p className="mt-1 text-sm text-gray-600">
            Find a tenant, then open it to change access or plan.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <a
            href="/api/export/tenants"
            className="rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-800 hover:bg-gray-50"
          >
            Export CSV
          </a>
          <Link href="/activation" className="text-sm text-admin-700 hover:underline">
            Activation cohorts
          </Link>
        </div>
      </div>

      <form action="/shops" className="flex flex-wrap gap-2">
        <input
          name="q"
          defaultValue={q ?? ''}
          placeholder="Name, phone, or email"
          className="h-10 min-w-[220px] flex-1 rounded-md border border-gray-300 bg-white px-3 text-sm"
        />
        <select
          name="status"
          defaultValue={status}
          className="h-10 rounded-md border border-gray-300 bg-white px-3 text-sm"
        >
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
        </select>
        <button
          type="submit"
          className="h-10 rounded-md bg-admin-600 px-4 text-sm font-medium text-white"
        >
          Search
        </button>
      </form>

      <Suspense fallback={<div className="h-40 animate-pulse rounded-xl bg-gray-200" />}>
        <ShopsData q={q} status={status} />
      </Suspense>
    </div>
  );
}
