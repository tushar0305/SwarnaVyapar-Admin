import { notFound } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getShopById } from '@/services/shop-management.service';
import { getShopOnboardingStatus } from '@/services/onboarding.service';
import { getShopAnalytics } from '@/services/shop-analytics.service';
import { getCommandCenter } from '@/services/command-center.service';
import { formatCurrency, formatDate, formatDateTime, formatNumber } from '@/lib/utils';
import { millicreditsToCredits, millicreditsToInr } from '@/lib/credits';
import { ShopActions } from './_components/shop-actions';
import { PlanOverride } from './_components/plan-override';
import { CreditControls } from './_components/credit-controls';
import { getShopMembers, getShopTimeline } from '@/services/tenant.service';
import { ArrowLeft, Store, Mail, Phone, MapPin } from 'lucide-react';
import Link from 'next/link';
import type { Shop } from '@/types';

export default async function ShopDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const shop = await getShopById(id).catch(() => null);
  if (!shop) notFound();

  const [onboarding, analytics, center, members, timeline] = await Promise.all([
    getShopOnboardingStatus(id).catch(() => null),
    getShopAnalytics(id).catch(() => null),
    getCommandCenter().catch(() => null),
    getShopMembers(id).catch(() => []),
    getShopTimeline(id, 60).catch(() => []),
  ]);
  const pulse = center?.tenants.find((row) => row.id === id);
  const planId = pulse?.planId || shop.subscriptions?.[0]?.plan_id || 'none';
  const planStatus = pulse?.subscriptionStatus || shop.subscriptions?.[0]?.status || 'none';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/shops">
              <ArrowLeft className="w-5 h-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Shop Details</h1>
            <p className="text-gray-600 mt-1">View and manage shop information</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" asChild>
            <Link href={`/shops/${id}/analytics`}>Activation</Link>
          </Button>
          <ShopActions shop={shop as Shop} />
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-admin-100 rounded-lg flex items-center justify-center">
                <Store className="w-8 h-8 text-admin-600" />
              </div>
              <div>
                <CardTitle className="text-2xl">{shop.shop_name}</CardTitle>
                <div className="flex items-center gap-3 mt-2">
                  {shop.is_suspended ? (
                    <Badge variant="destructive">Suspended</Badge>
                  ) : !shop.is_active ? (
                    <Badge variant="destructive">Inactive</Badge>
                  ) : (
                    <Badge variant="success">Active</Badge>
                  )}
                  <span className="text-sm text-gray-500">
                    Created {formatDate(shop.created_at)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900">Contact Information</h3>
              {shop.email && (
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-700">{shop.email}</span>
                </div>
              )}
              {shop.phone_number && (
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-700">{shop.phone_number}</span>
                </div>
              )}
              {shop.address && (
                <div className="flex items-start gap-3 text-sm">
                  <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                  <span className="text-gray-700">{shop.address}</span>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900">Business Details</h3>
              <div className="text-sm">
                <p className="text-gray-500">GST Number</p>
                <p className="font-mono text-gray-900">
                  {shop.gst_number || 'Not added'}
                </p>
              </div>
              <div className="text-sm">
                <p className="text-gray-500">Activation</p>
                <p className="text-gray-900">
                  {onboarding
                    ? `${Math.round(onboarding.overallProgress)}% core steps`
                    : '—'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          ['Sales, 30 days', formatCurrency(pulse?.gmv30d ?? 0)],
          ['Collected, 30 days', formatCurrency(pulse?.collected30d ?? 0)],
          ['Balance due', formatCurrency(pulse?.balanceDue ?? 0)],
          [
            'Credits left',
            `${formatNumber(millicreditsToCredits(pulse?.availableMc ?? 0))} · ${formatCurrency(millicreditsToInr(pulse?.availableMc ?? 0))}`,
          ],
        ].map(([label, value]) => (
          <div key={label} className="rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-xs uppercase tracking-wide text-gray-500">{label}</p>
            <p className="mt-1 text-lg font-semibold text-gray-950">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Plan override</CardTitle>
          </CardHeader>
          <CardContent>
            <PlanOverride shopId={id} planId={planId} status={planStatus} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Credits{pulse?.frozen ? ' · wallet frozen' : ''}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CreditControls shopId={id} frozen={Boolean(pulse?.frozen)} />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">People ({members.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {members.length === 0 ? (
              <p className="text-sm text-gray-500">No users are linked to this shop.</p>
            ) : (
              <ul className="divide-y divide-gray-100">
                {members.map((member) => (
                  <li key={member.userId} className="py-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-medium text-gray-950">
                        {member.email ?? member.userId}
                      </p>
                      <Badge variant={member.active ? 'secondary' : 'destructive'}>
                        {member.role}
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-gray-500">
                      {member.lastSignInAt
                        ? `Last sign-in ${formatDateTime(member.lastSignInAt)}`
                        : 'Never signed in'}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {timeline.length === 0 ? (
              <p className="text-sm text-gray-500">No recorded activity yet.</p>
            ) : (
              <ol className="max-h-[480px] space-y-3 overflow-y-auto pr-1">
                {timeline.map((event, index) => (
                  <li key={`${event.at}-${index}`} className="flex gap-3 text-sm">
                    <span className="mt-0.5 w-20 shrink-0 text-xs uppercase tracking-wide text-gray-400">
                      {event.kind}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium text-gray-900">{event.title}</p>
                      {event.detail ? (
                        <p className="truncate text-xs text-gray-500">{event.detail}</p>
                      ) : null}
                    </div>
                    <span className="shrink-0 text-xs text-gray-400">
                      {event.at ? formatDateTime(event.at) : ''}
                    </span>
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-600">
              Active seats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {analytics?.usage.activeUsers ?? 0}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-600">
              Subscription
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {shop.subscriptions?.[0]?.plan_id || 'None'}{' '}
              <span className="text-base font-normal text-gray-500">
                {shop.subscriptions?.[0]?.status || ''}
              </span>
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-gray-600">
              Created At
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-700">
              {formatDateTime(shop.created_at)}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
