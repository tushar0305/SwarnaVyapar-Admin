import { TrendingUp, AlertTriangle, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  getShopAnalytics,
  getShopActivityLogs,
} from '@/services/shop-analytics.service';
import { getShopOnboardingStatus } from '@/services/onboarding.service';
import { getShopPaymentHistory } from '@/services/billing.service';
import Link from 'next/link';

export default async function ShopAnalyticsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const [analytics, activityLogs, onboarding, payments] = await Promise.all([
    getShopAnalytics(id),
    getShopActivityLogs(id, 20),
    getShopOnboardingStatus(id),
    getShopPaymentHistory(id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">{analytics.shopName} — activation</h1>
        <p className="text-gray-600 mt-1">
          Usage from live tables.{' '}
          <Link href={`/shops/${id}`} className="text-admin-700 hover:underline">
            Shop details
          </Link>
        </p>
      </div>

      {/* Health Score */}
      <Card>
        <CardHeader>
          <CardTitle>Shop Health Score</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-gray-500">Overall Health</p>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex-1 bg-gray-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full ${
                      analytics.health.score > 70
                        ? 'bg-green-500'
                        : analytics.health.score > 40
                        ? 'bg-yellow-500'
                        : 'bg-red-500'
                    }`}
                    style={{ width: `${analytics.health.score}%` }}
                  />
                </div>
                <span className="text-2xl font-bold">{Math.round(analytics.health.score)}</span>
              </div>
            </div>
            <div>
              <p className="text-sm text-gray-500">Status</p>
              <Badge
                className={`mt-2 ${
                  analytics.health.status === 'healthy'
                    ? 'bg-green-100 text-green-700'
                    : analytics.health.status === 'at-risk'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-red-100 text-red-700'
                }`}
              >
                {analytics.health.status}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-gray-500">Churn Probability</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {(analytics.health.churnProbability * 100).toFixed(1)}%
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Revenue & Usage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              Plan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Plan price / month</span>
                <span className="text-lg font-bold">₹{analytics.revenue.monthly}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Plan</span>
                <span className="text-lg font-bold">
                  {analytics.subscription?.plan_id || 'none'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Status</span>
                <span className="text-sm font-medium">
                  {analytics.subscription?.status || 'none'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-admin-600" />
              Usage Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Invoices</p>
                <p className="text-2xl font-bold text-admin-600">
                  {analytics.usage.invoicesCount}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Customers</p>
                <p className="text-2xl font-bold text-admin-600">
                  {analytics.usage.customersCount}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Products</p>
                <p className="text-2xl font-bold text-admin-600">
                  {analytics.usage.productsCount}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Active Users</p>
                <p className="text-2xl font-bold text-admin-600">
                  {analytics.usage.activeUsers}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Onboarding Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Onboarding Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Overall Completion</span>
                <span className="text-sm font-bold">{Math.round(onboarding.overallProgress)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-admin-600 h-2 rounded-full"
                  style={{ width: `${onboarding.overallProgress}%` }}
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {onboarding.steps.map((step) => (
                <div
                  key={step.id}
                  className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg"
                >
                  {step.isCompleted ? (
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-white text-xs">
                      ✓
                    </div>
                  ) : (
                    <div className="w-6 h-6 bg-gray-300 rounded-full" />
                  )}
                  <div>
                    <p className="text-sm font-medium">{step.name}</p>
                    <p className="text-xs text-gray-500">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
            {onboarding.needsAssistance && (
              <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                <p className="text-sm text-yellow-800">
                  This shop may need onboarding assistance
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Feature Adoption */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Adoption</CardTitle>
        </CardHeader>
        <CardContent>
          {Object.keys(analytics.featureAdoption).length === 0 ? (
            <p className="text-sm text-gray-500">No feature overrides for this shop</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(analytics.featureAdoption).map(([key, data]) => (
                <div
                  key={key}
                  className="p-3 bg-gray-50 rounded-lg"
                >
                  <p className="text-sm font-medium capitalize">{key.replace(/_/g, ' ')}</p>
                  <Badge
                    className={`mt-1 ${
                      data.enabled
                        ? 'bg-green-100 text-green-700'
                        : 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    {data.enabled ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Payments</CardTitle>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <p className="text-sm text-gray-500">No payment history available</p>
          ) : (
            <div className="space-y-2">
              {payments.slice(0, 5).map((payment: any) => (
                <div
                  key={payment.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div>
                    <p className="text-sm font-medium">
                      {payment.currency} {payment.amount}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(payment.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge
                    className={
                      payment.status === 'completed'
                        ? 'bg-green-100 text-green-700'
                        : payment.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-red-100 text-red-700'
                    }
                  >
                    {payment.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Activity Logs */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {activityLogs.length === 0 ? (
            <p className="text-sm text-gray-500">No activity logs available</p>
          ) : (
            <div className="space-y-2">
              {activityLogs.slice(0, 10).map((log: any) => (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-2 hover:bg-gray-50 rounded"
                >
                  <div>
                    <p className="text-sm font-medium">{log.action}</p>
                    <p className="text-xs text-gray-500">{log.description}</p>
                  </div>
                  <p className="text-xs text-gray-400">
                    {new Date(log.created_at).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
