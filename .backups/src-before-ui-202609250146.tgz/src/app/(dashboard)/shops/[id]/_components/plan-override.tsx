'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { setShopPlan } from '@/services/billing.service';
import { toast } from 'sonner';

const PLANS = [
  { id: 'free', label: 'Starter' },
  { id: 'pro', label: 'Professional' },
  { id: 'business', label: 'Business' },
] as const;

export function PlanOverride({
  shopId,
  planId,
  status,
}: {
  shopId: string;
  planId: string;
  status: string;
}) {
  const router = useRouter();
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(formData: FormData) {
    const nextPlan = String(formData.get('planId') || '');
    const nextStatus = String(formData.get('status') || 'active');
    if (!reason.trim()) {
      toast.error('Write why you are changing this plan');
      return;
    }
    if (nextPlan !== 'free' && nextPlan !== 'pro' && nextPlan !== 'business') return;
    setLoading(true);
    try {
      await setShopPlan({
        shopId,
        planId: nextPlan,
        status: nextStatus as 'active' | 'past_due' | 'canceled' | 'trialing' | 'unpaid',
        reason,
      });
      toast.success('Plan updated. This does not charge Razorpay.');
      setReason('');
      router.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Plan update failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form action={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-sm text-gray-600">
          Plan
          <select
            name="planId"
            defaultValue={planId === 'pro' || planId === 'business' ? planId : 'free'}
            className="mt-1 h-10 w-full rounded-md border border-gray-300 bg-white px-3 text-sm text-gray-900"
          >
            {PLANS.map((plan) => (
              <option key={plan.id} value={plan.id}>
                {plan.label}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm text-gray-600">
          Status
          <select
            name="status"
            defaultValue={status && status !== 'none' ? status : 'active'}
            className="mt-1 h-10 w-full rounded-md border border-gray-300 bg-white px-3 text-sm text-gray-900"
          >
            <option value="active">Active</option>
            <option value="trialing">Trialing</option>
            <option value="past_due">Past due</option>
            <option value="unpaid">Unpaid</option>
            <option value="canceled">Canceled</option>
          </select>
        </label>
      </div>
      <label className="block text-sm text-gray-600">
        Reason (saved to the audit log)
        <input
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          className="mt-1 h-10 w-full rounded-md border border-gray-300 px-3 text-sm text-gray-900"
          placeholder="Comp Business for onboarding, 30 days"
        />
      </label>
      <button
        type="submit"
        disabled={loading}
        className="h-10 rounded-md bg-gray-950 px-4 text-sm font-medium text-white disabled:opacity-50"
      >
        {loading ? 'Saving…' : 'Save plan override'}
      </button>
      <p className="text-xs text-gray-500">
        Current: {planId === 'none' ? 'no plan' : planId} ·{' '}
        {status === 'none' ? 'no subscription row' : status}. Razorpay is not updated.
      </p>
    </form>
  );
}
