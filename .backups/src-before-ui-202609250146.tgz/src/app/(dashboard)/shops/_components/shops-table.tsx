'use client';

import { useRouter } from 'next/navigation';
import Link from 'next/link';
import type { Shop } from '@/types';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { formatDate } from '@/lib/utils';
import { ExternalLink, AlertCircle } from 'lucide-react';

function healthPercent(shop: Shop): number {
  const raw = Number(shop.health_score);
  if (!Number.isFinite(raw)) return 0;
  return raw <= 1 ? Math.round(raw * 100) : Math.round(raw);
}

interface ShopsTableProps {
  shops: Shop[];
}

export function ShopsTable({ shops }: ShopsTableProps) {
  const router = useRouter();

  if (shops.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-gray-500">No shops found</p>
      </Card>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Shop
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Contact
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Health
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Created
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {shops.map((shop) => (
              <tr key={shop.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4">
                  <div>
                    <Link
                      href={`/shops/${shop.id}`}
                      className="font-medium text-gray-900 hover:text-admin-600"
                    >
                      {shop.shop_name}
                    </Link>
                    <p className="text-xs text-gray-500 mt-1">{shop.gst_number || 'No GST'}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm">
                    {shop.phone_number && <p className="text-gray-900">{shop.phone_number}</p>}
                    {shop.email && (
                      <p className="text-gray-500 truncate max-w-[200px]">{shop.email}</p>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4">
                  {shop.is_suspended ? (
                    <Badge variant="destructive" className="gap-1">
                      <AlertCircle className="w-3 h-3" />
                      Suspended
                    </Badge>
                  ) : shop.is_active === false ? (
                    <Badge variant="secondary" className="gap-1">
                      Inactive
                    </Badge>
                  ) : (
                    <Badge variant="success">Active</Badge>
                  )}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className="w-16 bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          healthPercent(shop) > 70
                            ? 'bg-green-500'
                            : healthPercent(shop) > 40
                              ? 'bg-yellow-500'
                              : 'bg-red-500'
                        }`}
                        style={{ width: `${healthPercent(shop)}%` }}
                      />
                    </div>
                    <span className="text-xs text-gray-600">
                      {healthPercent(shop)}%
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  {formatDate(shop.created_at)}
                </td>
                <td className="px-6 py-4 text-right">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => router.push(`/shops/${shop.id}/analytics`)}
                  >
                    Health
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
