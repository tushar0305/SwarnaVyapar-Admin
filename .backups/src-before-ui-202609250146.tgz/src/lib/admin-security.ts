/** Client IP + session cookie helpers for admin proxy. */

export const ADMIN_SESSION_COOKIE = 'sv_admin_session_at';

/** ponytail: local-only. Production always requires login. Set ADMIN_BYPASS_AUTH=0 to turn login back on in `next dev`. */
export function isAdminAuthBypassed(
  nodeEnv = process.env.NODE_ENV,
  flag = process.env.ADMIN_BYPASS_AUTH
): boolean {
  if (nodeEnv === 'production') return false;
  return flag !== '0';
}

export function clientIp(headers: Headers): string {
  const forwarded = headers.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0]?.trim() || '';
  return headers.get('x-real-ip')?.trim() || '';
}

/** Empty whitelist = allow all (local dev). */
export function isIpAllowed(ip: string, whitelistCsv: string | undefined): boolean {
  const list = (whitelistCsv || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (list.length === 0) return true;
  if (!ip) return false;
  return list.includes(ip);
}

export function isAdminSessionExpired(
  startedAtMs: number | null,
  timeoutSeconds: number
): boolean {
  if (!timeoutSeconds || timeoutSeconds <= 0) return false;
  if (!startedAtMs) return true;
  return Date.now() - startedAtMs > timeoutSeconds * 1000;
}
